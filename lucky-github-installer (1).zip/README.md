# Lucky Reels - GitHub Installer

Upload `LuckyReels.zip` and the `.github/workflows/unpack-game.yml` workflow to the GitHub repository.

After upload, GitHub Actions will automatically extract the complete Lucky Reels project into the repository root and remove the ZIP.

Then deploy the repository to your cloud host.

Virtual coins only. No deposits, cash-out, or conversion to real money.
